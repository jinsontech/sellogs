 


<?php $__env->startSection('content'); ?>

<h2>Admin Login</h2>
<div class="container" id="container">
	<div class="form-container sign-in-container">
		<form action="<?php echo e(route('admin.handleLogin')); ?>" method="POST">
        <?php echo csrf_field(); ?>
			<h1>Sign in</h1>
			<?php if(session('error')): ?>
                <p style="color: red;font-weight:bold"><?php echo e(session('error')); ?></p>
            <?php endif; ?>
			<input type="username" name="username" placeholder="Username" />
			<input type="password" name="password" placeholder="Password" />
			<button type="submit">Sign In</button>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			
		</div>
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/jinson/sellogs/resources/views/admin/login.blade.php ENDPATH**/ ?>